Po uruchomieniu programu w VisualStudio należy podać parametry symulacji w konsoli.

Program wykona 100 symulacji, a średnie wyniki badanych parametrów zostaną zapisane do pliku log.txt znajdującego się w:
\MOPS\bin\Debug\netcoreapp3.1\logs